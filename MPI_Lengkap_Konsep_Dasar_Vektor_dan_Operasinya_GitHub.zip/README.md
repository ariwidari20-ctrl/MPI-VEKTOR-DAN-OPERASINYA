# MPI Konsep Dasar Vektor dan Operasinya — Kelas X SMK

MPI interaktif berbasis satu file HTML untuk belajar mandiri.

## Tujuan pembelajaran
1. Murid mampu menjelaskan konsep dasar vektor (besaran, arah, notasi, dan representasi geometris) secara mandiri.
2. Peserta didik mampu melakukan operasi aljabar vektor: penjumlahan, pengurangan, perkalian dengan skalar, dan perkalian titik (dot product).

## Fitur
- Materi konsep vektor, besaran skalar dan vektor, notasi, besar, arah, dan representasi geometris.
- Penjelasan operasi penjumlahan, pengurangan, perkalian skalar, dan perkalian titik.
- Simulasi operasi vektor dengan input komponen yang dapat diubah.
- Latihan dengan umpan balik dan pemeriksaan otomatis.
- Kuis akhir dengan nilai otomatis.
- Responsif untuk laptop, tablet, dan ponsel.
- Tidak memerlukan internet atau pustaka eksternal untuk menjalankan file.

## Menjalankan
Unduh `index.html`, lalu buka dengan browser modern.

## Hosting di GitHub Pages
1. Buat repository baru di GitHub, misalnya `mpi-vektor-operasi`.
2. Unggah `index.html` ke direktori utama repository.
3. Buka **Settings → Pages**.
4. Di **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/(root)`, lalu klik **Save**.
6. Setelah publikasi selesai, buka alamat yang ditampilkan GitHub Pages. Format biasanya `https://USERNAME.github.io/NAMA-REPOSITORY/`.

Catatan: file telah disiapkan untuk hosting, tetapi belum dipublikasikan ke akun GitHub pengguna.
